package com.ai2orbit.idabratings.white

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Displays device photos in a grid, lets the user select which ones to sync,
 * and uploads them to Salesforce as ContentVersion (Files).
 *
 * Shows sync status (checkmark for synced, spinner for syncing, X for failed).
 */
class SalesforcePhotoActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "SalesforcePhoto"
        private const val GRID_COLUMNS = 3
    }

    private lateinit var photoSyncService: PhotoSyncService
    private lateinit var auth: SalesforceAuth

    // UI
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var btnSyncSelected: Button
    private lateinit var btnSyncAll: Button
    private lateinit var btnSelectAll: Button
    private lateinit var headerUser: TextView
    private lateinit var headerCount: TextView
    private lateinit var emptyState: TextView
    private lateinit var syncProgressLayout: View
    private lateinit var syncProgressBar: ProgressBar
    private lateinit var syncProgressText: TextView
    private lateinit var btnBack: Button

    private val adapter = PhotoAdapter()
    private val executor = Executors.newSingleThreadExecutor()
    private var allPhotos: List<PhotoSyncService.DevicePhoto> = emptyList()
    private var isSyncing = false

    // ── Permission launcher ────────────────────────────────────────────

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            loadPhotos()
        } else {
            emptyState.visibility = View.VISIBLE
            emptyState.text = "Photo access permission is required to sync photos to Salesforce.\n\nPlease grant permission in Settings."
        }
    }

    // ── Lifecycle ──────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.parseColor("#0a0e17")
        window.navigationBarColor = Color.parseColor("#0a0e17")
        window.insetsController?.setSystemBarsAppearance(
            0,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )

        setContentView(R.layout.activity_salesforce_photos)

        auth = SalesforceAuth.getInstance(this)
        photoSyncService = PhotoSyncService(this)

        // Redirect to login if not authenticated
        if (!auth.isLoggedIn()) {
            startActivity(Intent(this, SalesforceLoginActivity::class.java))
            finish()
            return
        }

        bindViews()
        setupRecyclerView()
        setupListeners()
        checkPermissionAndLoad()
    }

    private fun bindViews() {
        recyclerView = findViewById(R.id.sfPhotoGrid)
        progressBar = findViewById(R.id.sfPhotoProgress)
        statusText = findViewById(R.id.sfPhotoStatus)
        btnSyncSelected = findViewById(R.id.sfBtnSyncSelected)
        btnSyncAll = findViewById(R.id.sfBtnSyncAll)
        btnSelectAll = findViewById(R.id.sfBtnSelectAll)
        headerUser = findViewById(R.id.sfPhotoUser)
        headerCount = findViewById(R.id.sfPhotoCount)
        emptyState = findViewById(R.id.sfPhotoEmpty)
        syncProgressLayout = findViewById(R.id.sfSyncProgressLayout)
        syncProgressBar = findViewById(R.id.sfSyncProgressBar)
        syncProgressText = findViewById(R.id.sfSyncProgressText)
        btnBack = findViewById(R.id.sfBtnBack)
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = GridLayoutManager(this, GRID_COLUMNS)
        recyclerView.adapter = adapter
        recyclerView.setHasFixedSize(true)
    }

    private fun setupListeners() {
        btnSyncSelected.setOnClickListener {
            val selected = adapter.getSelectedPhotos()
            if (selected.isEmpty()) {
                Toast.makeText(this, "Select photos to sync", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            confirmAndSync(selected)
        }

        btnSyncAll.setOnClickListener {
            val unsynced = allPhotos.filter { !photoSyncService.isPhotoSynced(it.id) }
            if (unsynced.isEmpty()) {
                Toast.makeText(this, "All photos are already synced", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            confirmAndSync(unsynced)
        }

        btnSelectAll.setOnClickListener {
            adapter.toggleSelectAll()
            updateSelectionCount()
        }

        btnBack.setOnClickListener {
            finish()
        }
    }

    // ── Permissions ────────────────────────────────────────────────────

    private fun checkPermissionAndLoad() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_IMAGES
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        when {
            ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED -> {
                loadPhotos()
            }
            shouldShowRequestPermissionRationale(permission) -> {
                AlertDialog.Builder(this, com.google.android.material.R.style.ThemeOverlay_Material3_MaterialAlertDialog)
                    .setTitle("Photo Access Required")
                    .setMessage("This app needs access to your photos to sync them to your Salesforce account.")
                    .setPositiveButton("Grant") { _, _ -> permissionLauncher.launch(permission) }
                    .setNegativeButton("Cancel") { _, _ -> finish() }
                    .show()
            }
            else -> {
                permissionLauncher.launch(permission)
            }
        }
    }

    // ── Load photos ────────────────────────────────────────────────────

    private fun loadPhotos() {
        progressBar.visibility = View.VISIBLE
        statusText.visibility = View.VISIBLE
        statusText.text = "Loading photos..."

        executor.execute {
            val photos = photoSyncService.getDevicePhotos()

            runOnUiThread {
                progressBar.visibility = View.GONE
                statusText.visibility = View.GONE

                allPhotos = photos
                adapter.setPhotos(photos)

                if (photos.isEmpty()) {
                    emptyState.visibility = View.VISIBLE
                    emptyState.text = "No photos found on this device"
                } else {
                    emptyState.visibility = View.GONE
                    val syncedCount = photos.count { photoSyncService.isPhotoSynced(it.id) }
                    headerCount.text = "${photos.size} photos | $syncedCount synced"
                }

                headerUser.text = auth.getUserName() ?: "Salesforce User"
            }
        }
    }

    // ── Sync photos ────────────────────────────────────────────────────

    private fun confirmAndSync(photos: List<PhotoSyncService.DevicePhoto>) {
        AlertDialog.Builder(this, com.google.android.material.R.style.ThemeOverlay_Material3_MaterialAlertDialog)
            .setTitle("Sync ${photos.size} photo(s)?")
            .setMessage("These photos will be uploaded to your Salesforce account as Files (ContentVersion).")
            .setPositiveButton("Sync") { _, _ -> startSync(photos) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startSync(photos: List<PhotoSyncService.DevicePhoto>) {
        if (isSyncing) return
        isSyncing = true

        // Show sync progress
        syncProgressLayout.visibility = View.VISIBLE
        syncProgressBar.max = photos.size
        syncProgressBar.progress = 0
        syncProgressText.text = "Starting sync..."

        btnSyncSelected.isEnabled = false
        btnSyncAll.isEnabled = false

        executor.execute {
            photoSyncService.uploadPhotos(photos, object : PhotoSyncService.SyncProgressListener {

                override fun onProgressUpdate(
                    current: Int,
                    total: Int,
                    photo: PhotoSyncService.DevicePhoto,
                    status: PhotoSyncService.SyncStatus
                ) {
                    runOnUiThread {
                        syncProgressBar.progress = current
                        val statusLabel = when (status) {
                            PhotoSyncService.SyncStatus.SYNCING -> "Uploading"
                            PhotoSyncService.SyncStatus.SYNCED -> "Done"
                            PhotoSyncService.SyncStatus.FAILED -> "Failed"
                            else -> ""
                        }
                        syncProgressText.text = "$statusLabel: ${photo.displayName} ($current/$total)"
                        adapter.updatePhotoStatus(photo.id, status)
                    }
                }

                override fun onComplete(results: List<PhotoSyncService.PhotoSyncResult>) {
                    val synced = results.count { it.status == PhotoSyncService.SyncStatus.SYNCED }
                    val failed = results.count { it.status == PhotoSyncService.SyncStatus.FAILED }

                    runOnUiThread {
                        isSyncing = false
                        syncProgressLayout.visibility = View.GONE
                        btnSyncSelected.isEnabled = true
                        btnSyncAll.isEnabled = true

                        val msg = "Sync complete: $synced uploaded" +
                                if (failed > 0) ", $failed failed" else ""
                        Toast.makeText(this@SalesforcePhotoActivity, msg, Toast.LENGTH_LONG).show()

                        // Refresh counts
                        val totalSynced = allPhotos.count { photoSyncService.isPhotoSynced(it.id) }
                        headerCount.text = "${allPhotos.size} photos | $totalSynced synced"

                        adapter.notifyDataSetChanged()
                    }
                }

                override fun onError(error: String) {
                    runOnUiThread {
                        isSyncing = false
                        syncProgressLayout.visibility = View.GONE
                        btnSyncSelected.isEnabled = true
                        btnSyncAll.isEnabled = true
                        Toast.makeText(this@SalesforcePhotoActivity, error, Toast.LENGTH_LONG).show()

                        // If auth error, redirect to login
                        if (error.contains("log in", ignoreCase = true) || error.contains("expired", ignoreCase = true)) {
                            startActivity(Intent(this@SalesforcePhotoActivity, SalesforceLoginActivity::class.java))
                        }
                    }
                }
            })
        }
    }

    private fun updateSelectionCount() {
        val count = adapter.getSelectedPhotos().size
        btnSyncSelected.text = if (count > 0) "Sync Selected ($count)" else "Sync Selected"
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    // ═══════════════════════════════════════════════════════════════════
    // ── RecyclerView Adapter ───────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════

    private inner class PhotoAdapter : RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder>() {

        private var photos: List<PhotoSyncService.DevicePhoto> = emptyList()
        private val selectedIds = mutableSetOf<Long>()
        private val statusMap = mutableMapOf<Long, PhotoSyncService.SyncStatus>()

        fun setPhotos(newPhotos: List<PhotoSyncService.DevicePhoto>) {
            photos = newPhotos
            selectedIds.clear()
            // Initialize status from sync prefs
            photos.forEach { photo ->
                statusMap[photo.id] = photoSyncService.getSyncStatus(photo.id)
            }
            notifyDataSetChanged()
        }

        fun getSelectedPhotos(): List<PhotoSyncService.DevicePhoto> {
            return photos.filter { selectedIds.contains(it.id) }
        }

        fun toggleSelectAll() {
            if (selectedIds.size == photos.size) {
                selectedIds.clear()
            } else {
                photos.forEach { selectedIds.add(it.id) }
            }
            notifyDataSetChanged()
        }

        fun updatePhotoStatus(photoId: Long, status: PhotoSyncService.SyncStatus) {
            statusMap[photoId] = status
            val position = photos.indexOfFirst { it.id == photoId }
            if (position >= 0) {
                notifyItemChanged(position)
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_photo, parent, false)
            return PhotoViewHolder(view)
        }

        override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
            val photo = photos[position]
            holder.bind(photo)
        }

        override fun getItemCount() = photos.size

        inner class PhotoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val imageView: ImageView = itemView.findViewById(R.id.photoImage)
            private val checkBox: CheckBox = itemView.findViewById(R.id.photoCheckBox)
            private val statusIcon: TextView = itemView.findViewById(R.id.photoStatusIcon)
            private val nameText: TextView = itemView.findViewById(R.id.photoName)
            private val sizeText: TextView = itemView.findViewById(R.id.photoSize)

            fun bind(photo: PhotoSyncService.DevicePhoto) {
                // Load thumbnail
                try {
                    imageView.setImageURI(photo.uri)
                } catch (e: Exception) {
                    imageView.setImageResource(android.R.drawable.ic_menu_gallery)
                }

                nameText.text = photo.displayName
                sizeText.text = formatDate(photo.dateAdded)

                // Selection
                checkBox.isChecked = selectedIds.contains(photo.id)
                checkBox.setOnCheckedChangeListener(null) // Remove old listener
                checkBox.setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) {
                        selectedIds.add(photo.id)
                    } else {
                        selectedIds.remove(photo.id)
                    }
                    updateSelectionCount()
                }

                // Sync status icon
                val status = statusMap[photo.id] ?: PhotoSyncService.SyncStatus.NOT_SYNCED
                when (status) {
                    PhotoSyncService.SyncStatus.SYNCED -> {
                        statusIcon.visibility = View.VISIBLE
                        statusIcon.text = "✓" // checkmark
                        statusIcon.setTextColor(Color.parseColor("#00E676"))
                    }
                    PhotoSyncService.SyncStatus.SYNCING -> {
                        statusIcon.visibility = View.VISIBLE
                        statusIcon.text = "•••" // dots
                        statusIcon.setTextColor(Color.parseColor("#00BCD4"))
                    }
                    PhotoSyncService.SyncStatus.FAILED -> {
                        statusIcon.visibility = View.VISIBLE
                        statusIcon.text = "✗" // X mark
                        statusIcon.setTextColor(Color.parseColor("#FF5252"))
                    }
                    PhotoSyncService.SyncStatus.NOT_SYNCED -> {
                        statusIcon.visibility = View.GONE
                    }
                }

                // Click on item toggles selection
                itemView.setOnClickListener {
                    checkBox.isChecked = !checkBox.isChecked
                }
            }

            private fun formatDate(epochSeconds: Long): String {
                return try {
                    val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
                    sdf.format(Date(epochSeconds * 1000))
                } catch (e: Exception) {
                    ""
                }
            }
        }
    }
}
