package com.ai2orbit.idabratings.white

import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

/**
 * Accesses device photos via MediaStore and uploads them to Salesforce
 * as ContentVersion objects (Salesforce Files / Content).
 *
 * Each uploaded photo becomes a ContentVersion record that appears in
 * the user's Salesforce Files tab.
 */
class PhotoSyncService(private val context: Context) {

    companion object {
        private const val TAG = "PhotoSyncService"
    }

    private val auth = SalesforceAuth.getInstance(context)
    private val gson = Gson()
    private val syncPrefs by lazy {
        context.getSharedPreferences(SalesforceConfig.SYNC_PREFS_NAME, Context.MODE_PRIVATE)
    }

    // ── Data classes ───────────────────────────────────────────────────

    data class DevicePhoto(
        val id: Long,
        val uri: Uri,
        val displayName: String,
        val mimeType: String,
        val size: Long,
        val dateAdded: Long,
        val dateTaken: Long,
        val width: Int,
        val height: Int
    )

    enum class SyncStatus {
        NOT_SYNCED,
        SYNCING,
        SYNCED,
        FAILED
    }

    data class PhotoSyncResult(
        val photo: DevicePhoto,
        val status: SyncStatus,
        val contentVersionId: String? = null,
        val errorMessage: String? = null
    )

    data class ContentVersionResponse(
        @SerializedName("id") val id: String?,
        @SerializedName("success") val success: Boolean?,
        @SerializedName("errors") val errors: List<Any>?
    )

    data class ContentVersionRecord(
        @SerializedName("Id") val id: String?,
        @SerializedName("Title") val title: String?,
        @SerializedName("ContentDocumentId") val contentDocumentId: String?,
        @SerializedName("VersionNumber") val versionNumber: String?,
        @SerializedName("FileType") val fileType: String?,
        @SerializedName("ContentSize") val contentSize: Long?,
        @SerializedName("CreatedDate") val createdDate: String?
    )

    data class QueryResponse(
        @SerializedName("totalSize") val totalSize: Int?,
        @SerializedName("done") val done: Boolean?,
        @SerializedName("records") val records: List<ContentVersionRecord>?
    )

    // ── Listener interface ─────────────────────────────────────────────

    interface SyncProgressListener {
        fun onProgressUpdate(current: Int, total: Int, photo: DevicePhoto, status: SyncStatus)
        fun onComplete(results: List<PhotoSyncResult>)
        fun onError(error: String)
    }

    // ── Query device photos ────────────────────────────────────────────

    /**
     * Query all photos on the device via MediaStore.
     * Must be called with READ_MEDIA_IMAGES (API 33+) or READ_EXTERNAL_STORAGE permission.
     */
    fun getDevicePhotos(limit: Int = 500): List<DevicePhoto> {
        val photos = mutableListOf<DevicePhoto>()
        val contentResolver: ContentResolver = context.contentResolver

        val collection: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT
        )

        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"

        val cursor: Cursor? = contentResolver.query(
            collection,
            projection,
            null,
            null,
            sortOrder
        )

        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = it.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val mimeCol = it.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            val sizeCol = it.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val dateAddedCol = it.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            val dateTakenCol = it.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
            val widthCol = it.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val heightCol = it.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)

            var count = 0
            while (it.moveToNext() && count < limit) {
                val id = it.getLong(idCol)
                val contentUri = Uri.withAppendedPath(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    id.toString()
                )

                photos.add(
                    DevicePhoto(
                        id = id,
                        uri = contentUri,
                        displayName = it.getString(nameCol) ?: "photo_$id.jpg",
                        mimeType = it.getString(mimeCol) ?: "image/jpeg",
                        size = it.getLong(sizeCol),
                        dateAdded = it.getLong(dateAddedCol),
                        dateTaken = it.getLong(dateTakenCol),
                        width = it.getInt(widthCol),
                        height = it.getInt(heightCol)
                    )
                )
                count++
            }
        }

        return photos
    }

    // ── Sync status tracking ───────────────────────────────────────────

    /** Get the set of already-synced photo IDs. */
    fun getSyncedPhotoIds(): Set<String> {
        return syncPrefs.getStringSet(SalesforceConfig.PREF_SYNCED_PHOTOS, emptySet()) ?: emptySet()
    }

    /** Check if a specific photo has been synced. */
    fun isPhotoSynced(photoId: Long): Boolean {
        return getSyncedPhotoIds().contains(photoId.toString())
    }

    /** Mark a photo as synced. */
    private fun markPhotoSynced(photoId: Long) {
        val current = getSyncedPhotoIds().toMutableSet()
        current.add(photoId.toString())
        syncPrefs.edit()
            .putStringSet(SalesforceConfig.PREF_SYNCED_PHOTOS, current)
            .apply()
    }

    /** Get sync status for a photo. */
    fun getSyncStatus(photoId: Long): SyncStatus {
        return if (isPhotoSynced(photoId)) SyncStatus.SYNCED else SyncStatus.NOT_SYNCED
    }

    // ── Upload to Salesforce ───────────────────────────────────────────

    /**
     * Upload a single photo to Salesforce as a ContentVersion.
     * Must be called from a background thread.
     *
     * Uses base64 encoding in the JSON body (simpler than multipart for moderate file sizes).
     * For files > 25 MB, consider multipart/form-data instead.
     */
    @Throws(IOException::class, SalesforceAuth.SalesforceAuthException::class)
    fun uploadPhoto(photo: DevicePhoto): PhotoSyncResult {
        // Validate file size
        if (photo.size > SalesforceConfig.MAX_UPLOAD_SIZE_BYTES) {
            return PhotoSyncResult(
                photo = photo,
                status = SyncStatus.FAILED,
                errorMessage = "File too large (${photo.size / 1024 / 1024} MB). Max: ${SalesforceConfig.MAX_UPLOAD_SIZE_BYTES / 1024 / 1024} MB"
            )
        }

        // Skip if already synced
        if (isPhotoSynced(photo.id)) {
            return PhotoSyncResult(
                photo = photo,
                status = SyncStatus.SYNCED,
                errorMessage = "Already synced"
            )
        }

        // Read the photo bytes
        val photoBytes: ByteArray = try {
            context.contentResolver.openInputStream(photo.uri)?.use { it.readBytes() }
                ?: throw IOException("Could not read photo: ${photo.displayName}")
        } catch (e: SecurityException) {
            return PhotoSyncResult(
                photo = photo,
                status = SyncStatus.FAILED,
                errorMessage = "Permission denied reading photo"
            )
        }

        // Base64 encode for the JSON body
        val base64Data = Base64.encodeToString(photoBytes, Base64.NO_WRAP)

        // Build the ContentVersion JSON payload
        val title = photo.displayName.substringBeforeLast(".", photo.displayName)
        val extension = photo.displayName.substringAfterLast(".", "jpg")
        val payload = mapOf(
            "Title" to title,
            "PathOnClient" to photo.displayName,
            "VersionData" to base64Data,
            "Description" to "Synced from IDAB Ratings Android app | ${photo.width}x${photo.height} | ${formatFileSize(photo.size)}",
            "Origin" to "C" // Content origin
        )

        val jsonBody = gson.toJson(payload)
        val instanceUrl = auth.getInstanceUrl()
            ?: throw SalesforceAuth.SalesforceAuthException("No instance URL — please log in")

        val url = instanceUrl + SalesforceConfig.CONTENT_VERSION_PATH
        val requestBuilder = Request.Builder()
            .url(url)
            .post(jsonBody.toRequestBody("application/json".toMediaType()))

        val response = auth.executeAuthenticatedRequest(requestBuilder)
        val responseBody = response.body?.string()
        response.close()

        if (!response.isSuccessful) {
            Log.e(TAG, "Upload failed for ${photo.displayName}: ${response.code} - $responseBody")
            return PhotoSyncResult(
                photo = photo,
                status = SyncStatus.FAILED,
                errorMessage = "Upload failed (${response.code}): ${extractErrorMessage(responseBody)}"
            )
        }

        val result = try {
            gson.fromJson(responseBody, ContentVersionResponse::class.java)
        } catch (e: Exception) {
            null
        }

        return if (result?.success == true && result.id != null) {
            markPhotoSynced(photo.id)
            Log.d(TAG, "Uploaded ${photo.displayName} -> ContentVersion ${result.id}")
            PhotoSyncResult(
                photo = photo,
                status = SyncStatus.SYNCED,
                contentVersionId = result.id
            )
        } else {
            PhotoSyncResult(
                photo = photo,
                status = SyncStatus.FAILED,
                errorMessage = "Upload returned unexpected response"
            )
        }
    }

    /**
     * Upload multiple photos with progress callbacks.
     * Must be called from a background thread.
     */
    fun uploadPhotos(photos: List<DevicePhoto>, listener: SyncProgressListener) {
        val results = mutableListOf<PhotoSyncResult>()

        for ((index, photo) in photos.withIndex()) {
            listener.onProgressUpdate(index + 1, photos.size, photo, SyncStatus.SYNCING)

            val result = try {
                uploadPhoto(photo)
            } catch (e: SalesforceAuth.SalesforceAuthException) {
                listener.onError(e.message ?: "Authentication error")
                return
            } catch (e: IOException) {
                PhotoSyncResult(
                    photo = photo,
                    status = SyncStatus.FAILED,
                    errorMessage = "Network error: ${e.message}"
                )
            } catch (e: Exception) {
                PhotoSyncResult(
                    photo = photo,
                    status = SyncStatus.FAILED,
                    errorMessage = "Unexpected error: ${e.message}"
                )
            }

            results.add(result)
            listener.onProgressUpdate(index + 1, photos.size, photo, result.status)
        }

        listener.onComplete(results)
    }

    // ── Query Salesforce files ─────────────────────────────────────────

    /**
     * Query ContentVersion records uploaded by this user.
     * Must be called from a background thread.
     */
    @Throws(IOException::class, SalesforceAuth.SalesforceAuthException::class)
    fun getSalesforceFiles(limit: Int = 50): List<ContentVersionRecord> {
        val instanceUrl = auth.getInstanceUrl()
            ?: throw SalesforceAuth.SalesforceAuthException("Not logged in")

        val soql = "SELECT Id, Title, ContentDocumentId, VersionNumber, FileType, ContentSize, CreatedDate " +
                "FROM ContentVersion " +
                "WHERE IsLatest = true AND Origin = 'C' " +
                "ORDER BY CreatedDate DESC " +
                "LIMIT $limit"

        val url = Uri.parse(instanceUrl + SalesforceConfig.QUERY_PATH)
            .buildUpon()
            .appendQueryParameter("q", soql)
            .build()
            .toString()

        val requestBuilder = Request.Builder()
            .url(url)
            .get()

        val response = auth.executeAuthenticatedRequest(requestBuilder)
        val responseBody = response.body?.string()
        response.close()

        if (!response.isSuccessful) {
            throw IOException("Query failed (${response.code}): ${extractErrorMessage(responseBody)}")
        }

        val queryResult = gson.fromJson(responseBody, QueryResponse::class.java)
        return queryResult.records ?: emptyList()
    }

    // ── Utilities ──────────────────────────────────────────────────────

    private fun extractErrorMessage(responseBody: String?): String {
        if (responseBody == null) return "No response body"
        return try {
            // Salesforce errors come as a JSON array
            val errors = gson.fromJson(responseBody, Array<SalesforceError>::class.java)
            errors.firstOrNull()?.message ?: responseBody.take(200)
        } catch (e: Exception) {
            responseBody.take(200)
        }
    }

    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            else -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
        }
    }

    data class SalesforceError(
        @SerializedName("message") val message: String?,
        @SerializedName("errorCode") val errorCode: String?,
        @SerializedName("fields") val fields: List<String>?
    )
}
