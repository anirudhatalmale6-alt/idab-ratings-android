package com.ai2orbit.financekensington.white

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

/**
 * AI2ORBIT Finance Kensington - White Theme
 *
 * Financial market data dashboard rendered in a hardware-accelerated WebView.
 * Displays simulated real-time prices for major indices, currencies, and commodities.
 * Charts are drawn with Canvas 2D; price ticks are driven by JavaScript setInterval.
 *
 * Certificate Transparency: WebView on Android 10+ honours CT by default for
 * connections made from the WebView networking stack. The network_security_config
 * enforces HTTPS-only and provides a pin-set placeholder for production API hosts.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        setContentView(webView)

        configureWebView()
        loadDashboard()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_NO_CACHE
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            // Hardware acceleration is set in the manifest; safe browsing is on by default.
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
    }

    private fun loadDashboard() {
        webView.loadDataWithBaseURL(
            "https://app.ai2orbit.com",
            DASHBOARD_HTML,
            "text/html",
            "UTF-8",
            null
        )
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        webView.evaluateJavascript("if(typeof resumeUpdates==='function')resumeUpdates();", null)
    }

    override fun onPause() {
        webView.evaluateJavascript("if(typeof pauseUpdates==='function')pauseUpdates();", null)
        super.onPause()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"/>
<title>Finance Kensington</title>
<style>
:root {
  --primary: #1565C0;
  --primary-dark: #0D47A1;
  --primary-light: #42A5F5;
  --bg: #FFFFFF;
  --surface: #FFFFFF;
  --surface-alt: #F8F9FA;
  --text: #212121;
  --text-secondary: #757575;
  --border: #E0E0E0;
  --positive: #2E7D32;
  --negative: #C62828;
  --shadow: 0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.06);
  --shadow-md: 0 4px 6px rgba(0,0,0,0.07), 0 2px 4px rgba(0,0,0,0.05);
  --radius: 12px;
}

* { margin:0; padding:0; box-sizing:border-box; }

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  background: var(--surface-alt);
  color: var(--text);
  -webkit-font-smoothing: antialiased;
  overflow-x: hidden;
}

/* Header */
.header {
  background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
  color: #fff;
  padding: 20px 16px 16px;
  position: sticky;
  top: 0;
  z-index: 100;
}
.header h1 {
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 0.3px;
}
.header .subtitle {
  font-size: 12px;
  opacity: 0.85;
  margin-top: 2px;
  font-weight: 400;
}
.header .status-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 12px;
  font-size: 11px;
  opacity: 0.9;
}
.status-dot {
  display: inline-block;
  width: 7px; height: 7px;
  border-radius: 50%;
  background: #69F0AE;
  margin-right: 5px;
  animation: pulse 2s infinite;
}
@keyframes pulse {
  0%,100% { opacity:1; }
  50% { opacity:0.4; }
}

/* Section titles */
.section-title {
  font-size: 13px;
  font-weight: 700;
  color: var(--primary);
  text-transform: uppercase;
  letter-spacing: 1px;
  padding: 18px 16px 8px;
}

/* Card grid */
.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(155px, 1fr));
  gap: 10px;
  padding: 0 12px 6px;
}

/* Market card */
.card {
  background: var(--surface);
  border-radius: var(--radius);
  padding: 14px;
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
  transition: box-shadow 0.2s, transform 0.15s;
  cursor: default;
}
.card:active {
  transform: scale(0.98);
  box-shadow: var(--shadow-md);
}
.card .label {
  font-size: 11px;
  color: var(--text-secondary);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 6px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.card .price {
  font-size: 20px;
  font-weight: 700;
  color: var(--text);
  line-height: 1.2;
}
.card .change {
  font-size: 12px;
  font-weight: 600;
  margin-top: 4px;
  display: flex;
  align-items: center;
  gap: 3px;
}
.card .change.up { color: var(--positive); }
.card .change.down { color: var(--negative); }
.card .change .arrow-up::before { content: '\25B2'; font-size: 9px; }
.card .change .arrow-down::before { content: '\25BC'; font-size: 9px; }
.card .mini-spark {
  margin-top: 8px;
  height: 32px;
  width: 100%;
}
.card .mini-spark canvas {
  width: 100%;
  height: 100%;
}

/* Charts section */
.charts-section {
  padding: 0 12px 12px;
}
.chart-card {
  background: var(--surface);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  border: 1px solid var(--border);
  margin-bottom: 12px;
  overflow: hidden;
}
.chart-card .chart-header {
  padding: 14px 16px 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.chart-card .chart-title {
  font-size: 15px;
  font-weight: 700;
  color: var(--text);
}
.chart-card .chart-value {
  font-size: 14px;
  font-weight: 700;
}
.chart-card .chart-body {
  padding: 0 8px 12px;
}
.chart-card canvas {
  width: 100%;
  height: 180px;
  display: block;
}

/* Summary bar */
.summary-bar {
  background: var(--surface);
  border-top: 1px solid var(--border);
  padding: 12px 16px;
  display: flex;
  justify-content: space-around;
  text-align: center;
  position: sticky;
  bottom: 0;
}
.summary-bar .col .val {
  font-size: 16px;
  font-weight: 700;
  color: var(--primary);
}
.summary-bar .col .lbl {
  font-size: 10px;
  color: var(--text-secondary);
  text-transform: uppercase;
  margin-top: 2px;
  letter-spacing: 0.3px;
}

/* Footer */
.footer {
  text-align: center;
  padding: 14px;
  font-size: 10px;
  color: var(--text-secondary);
}
</style>
</head>
<body>

<!-- Header -->
<div class="header">
  <h1>Finance Kensington</h1>
  <div class="subtitle">AI2ORBIT Market Intelligence</div>
  <div class="status-bar">
    <span><span class="status-dot"></span>Live Simulation</span>
    <span id="clock"></span>
  </div>
</div>

<!-- Indices -->
<div class="section-title">Indices</div>
<div class="card-grid" id="indices-grid"></div>

<!-- Currencies & Commodities -->
<div class="section-title">FX &amp; Commodities</div>
<div class="card-grid" id="fx-grid"></div>

<!-- Charts -->
<div class="section-title">Intraday Charts</div>
<div class="charts-section" id="charts-section"></div>

<!-- Summary bar -->
<div class="summary-bar">
  <div class="col"><div class="val" id="sum-up">0</div><div class="lbl">Advancing</div></div>
  <div class="col"><div class="val" id="sum-down">0</div><div class="lbl">Declining</div></div>
  <div class="col"><div class="val" id="sum-vol">0</div><div class="lbl">Ticks</div></div>
</div>

<div class="footer">AI2ORBIT Finance Kensington v7.0 &bull; Simulated Data &bull; Not Financial Advice</div>

<script>
/* ===== DATA MODEL ===== */
var instruments = [
  { id:'ftse',  name:'FTSE 100',  price:8245.30, group:'index',  dp:2 },
  { id:'sp500', name:'S&P 500',   price:5892.15, group:'index',  dp:2 },
  { id:'nasdaq',name:'NASDAQ',    price:18734.60,group:'index',  dp:2 },
  { id:'dax',   name:'DAX',       price:18456.80,group:'index',  dp:2 },
  { id:'nikkei',name:'Nikkei 225',price:38920.50,group:'index',  dp:2 },
  { id:'eurgbp',name:'EUR / GBP', price:0.8562,  group:'fx',     dp:4 },
  { id:'usdgbp',name:'USD / GBP', price:0.7935,  group:'fx',     dp:4 },
  { id:'gold',  name:'Gold',      price:2365.40, group:'comm',   dp:2 },
  { id:'brent', name:'Brent Crude',price:82.45,  group:'comm',   dp:2 }
];

var chartInstruments = ['ftse','sp500','dax'];
var history = {};
var sparkHistory = {};
var tickCount = 0;
var timerId = null;
var HISTORY_LEN = 80;
var SPARK_LEN = 20;

instruments.forEach(function(ins) {
  history[ins.id] = [ins.price];
  sparkHistory[ins.id] = [ins.price];
});

/* ===== RENDER CARDS ===== */
function renderCards() {
  var indicesGrid = document.getElementById('indices-grid');
  var fxGrid = document.getElementById('fx-grid');
  indicesGrid.innerHTML = '';
  fxGrid.innerHTML = '';

  instruments.forEach(function(ins) {
    var card = document.createElement('div');
    card.className = 'card';
    card.id = 'card-' + ins.id;
    card.innerHTML =
      '<div class="label">' + ins.name + '</div>' +
      '<div class="price" id="price-' + ins.id + '">' + formatNum(ins.price, ins.dp) + '</div>' +
      '<div class="change" id="change-' + ins.id + '"><span class="arrow"></span><span class="txt"></span></div>' +
      '<div class="mini-spark"><canvas id="spark-' + ins.id + '"></canvas></div>';

    if (ins.group === 'index') {
      indicesGrid.appendChild(card);
    } else {
      fxGrid.appendChild(card);
    }
  });
}

/* ===== RENDER CHARTS ===== */
function renderChartContainers() {
  var section = document.getElementById('charts-section');
  section.innerHTML = '';
  chartInstruments.forEach(function(id) {
    var ins = instrumentById(id);
    var div = document.createElement('div');
    div.className = 'chart-card';
    div.innerHTML =
      '<div class="chart-header">' +
        '<span class="chart-title">' + ins.name + '</span>' +
        '<span class="chart-value" id="cv-' + id + '">' + formatNum(ins.price, ins.dp) + '</span>' +
      '</div>' +
      '<div class="chart-body"><canvas id="chart-' + id + '"></canvas></div>';
    section.appendChild(div);
  });
}

/* ===== UTILITY ===== */
function instrumentById(id) {
  for (var i = 0; i < instruments.length; i++) {
    if (instruments[i].id === id) return instruments[i];
  }
  return null;
}

function formatNum(n, dp) {
  return n.toLocaleString('en-GB', { minimumFractionDigits: dp, maximumFractionDigits: dp });
}

/* ===== TICK ===== */
function tick() {
  tickCount++;
  var upCount = 0, downCount = 0;

  instruments.forEach(function(ins) {
    var volatility = ins.group === 'fx' ? 0.0003 : (ins.price > 10000 ? 0.001 : 0.002);
    var change = ins.price * volatility * (Math.random() - 0.48);
    ins.price = Math.max(ins.price * 0.9, ins.price + change);

    // Spark history
    sparkHistory[ins.id].push(ins.price);
    if (sparkHistory[ins.id].length > SPARK_LEN) sparkHistory[ins.id].shift();

    // Chart history
    if (chartInstruments.indexOf(ins.id) >= 0) {
      history[ins.id].push(ins.price);
      if (history[ins.id].length > HISTORY_LEN) history[ins.id].shift();
    }

    // Update DOM
    var priceEl = document.getElementById('price-' + ins.id);
    var changeEl = document.getElementById('change-' + ins.id);
    if (priceEl) priceEl.textContent = formatNum(ins.price, ins.dp);

    var diff = change;
    var pct = ((diff / (ins.price - diff)) * 100).toFixed(2);
    var isUp = diff >= 0;
    if (isUp) upCount++; else downCount++;

    if (changeEl) {
      changeEl.className = 'change ' + (isUp ? 'up' : 'down');
      changeEl.innerHTML =
        '<span class="arrow-' + (isUp ? 'up' : 'down') + '"></span>' +
        '<span class="txt">' + (isUp ? '+' : '') + pct + '%</span>';
    }

    // Mini sparkline
    drawSparkline(ins.id, isUp);
  });

  // Charts
  chartInstruments.forEach(function(id) {
    drawChart(id);
    var ins = instrumentById(id);
    var cv = document.getElementById('cv-' + id);
    if (cv) {
      var first = history[id][0];
      var isUp = ins.price >= first;
      cv.style.color = isUp ? '#2E7D32' : '#C62828';
      cv.textContent = formatNum(ins.price, ins.dp);
    }
  });

  // Summary
  document.getElementById('sum-up').textContent = upCount;
  document.getElementById('sum-down').textContent = downCount;
  document.getElementById('sum-vol').textContent = tickCount;

  // Clock
  var now = new Date();
  document.getElementById('clock').textContent =
    now.toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
}

/* ===== SPARKLINE ===== */
function drawSparkline(id, isUp) {
  var canvas = document.getElementById('spark-' + id);
  if (!canvas) return;
  var dpr = window.devicePixelRatio || 1;
  var rect = canvas.parentElement.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  var ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  var w = rect.width, h = rect.height;

  var data = sparkHistory[id];
  if (data.length < 2) return;
  var min = Math.min.apply(null, data);
  var max = Math.max.apply(null, data);
  var range = max - min || 1;

  ctx.clearRect(0, 0, w, h);
  ctx.beginPath();
  for (var i = 0; i < data.length; i++) {
    var x = (i / (data.length - 1)) * w;
    var y = h - ((data[i] - min) / range) * (h - 4) - 2;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = isUp ? '#2E7D32' : '#C62828';
  ctx.lineWidth = 1.5;
  ctx.lineJoin = 'round';
  ctx.stroke();

  // Fill gradient
  ctx.lineTo(w, h);
  ctx.lineTo(0, h);
  ctx.closePath();
  var grad = ctx.createLinearGradient(0, 0, 0, h);
  if (isUp) {
    grad.addColorStop(0, 'rgba(46,125,50,0.15)');
    grad.addColorStop(1, 'rgba(46,125,50,0.0)');
  } else {
    grad.addColorStop(0, 'rgba(198,40,40,0.15)');
    grad.addColorStop(1, 'rgba(198,40,40,0.0)');
  }
  ctx.fillStyle = grad;
  ctx.fill();
}

/* ===== CHART ===== */
function drawChart(id) {
  var canvas = document.getElementById('chart-' + id);
  if (!canvas) return;
  var dpr = window.devicePixelRatio || 1;
  var rect = canvas.parentElement.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = 180 * dpr;
  var ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  var w = rect.width, h = 180;

  var data = history[id];
  if (data.length < 2) return;
  var min = Math.min.apply(null, data);
  var max = Math.max.apply(null, data);
  var range = max - min || 1;
  var padT = 12, padB = 24, padL = 48, padR = 12;
  var cw = w - padL - padR;
  var ch = h - padT - padB;

  ctx.clearRect(0, 0, w, h);

  // Grid lines
  ctx.strokeStyle = '#F0F0F0';
  ctx.lineWidth = 1;
  for (var g = 0; g <= 4; g++) {
    var gy = padT + (ch / 4) * g;
    ctx.beginPath();
    ctx.moveTo(padL, gy);
    ctx.lineTo(w - padR, gy);
    ctx.stroke();

    var label = (max - (range / 4) * g).toFixed(data[0] > 100 ? 0 : 2);
    ctx.fillStyle = '#BDBDBD';
    ctx.font = '10px -apple-system, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(label, padL - 6, gy + 3);
  }

  // Data line
  var isUp = data[data.length - 1] >= data[0];
  var lineColor = isUp ? '#2E7D32' : '#C62828';
  ctx.beginPath();
  for (var i = 0; i < data.length; i++) {
    var x = padL + (i / (data.length - 1)) * cw;
    var y = padT + ch - ((data[i] - min) / range) * ch;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = lineColor;
  ctx.lineWidth = 2;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';
  ctx.stroke();

  // Fill
  ctx.lineTo(padL + cw, padT + ch);
  ctx.lineTo(padL, padT + ch);
  ctx.closePath();
  var grad = ctx.createLinearGradient(0, padT, 0, padT + ch);
  if (isUp) {
    grad.addColorStop(0, 'rgba(46,125,50,0.12)');
    grad.addColorStop(1, 'rgba(46,125,50,0.0)');
  } else {
    grad.addColorStop(0, 'rgba(198,40,40,0.12)');
    grad.addColorStop(1, 'rgba(198,40,40,0.0)');
  }
  ctx.fillStyle = grad;
  ctx.fill();

  // Latest price dot
  var lastX = padL + cw;
  var lastY = padT + ch - ((data[data.length - 1] - min) / range) * ch;
  ctx.beginPath();
  ctx.arc(lastX, lastY, 4, 0, Math.PI * 2);
  ctx.fillStyle = lineColor;
  ctx.fill();
  ctx.beginPath();
  ctx.arc(lastX, lastY, 2, 0, Math.PI * 2);
  ctx.fillStyle = '#FFFFFF';
  ctx.fill();
}

/* ===== LIFECYCLE ===== */
function startUpdates() {
  if (!timerId) timerId = setInterval(tick, 1500);
}
function pauseUpdates() {
  if (timerId) { clearInterval(timerId); timerId = null; }
}
function resumeUpdates() {
  startUpdates();
}

/* ===== INIT ===== */
renderCards();
renderChartContainers();
tick();
startUpdates();
</script>
</body>
</html>
"""
    }
}
