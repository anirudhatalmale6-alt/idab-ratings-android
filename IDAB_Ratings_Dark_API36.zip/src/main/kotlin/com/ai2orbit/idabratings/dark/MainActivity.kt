package com.ai2orbit.idabratings.dark

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowInsetsController
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.parseColor("#0a0e17")
        window.navigationBarColor = Color.parseColor("#0a0e17")
        window.insetsController?.setSystemBarsAppearance(
            0,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#0a0e17"))
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        setContentView(webView)

        configureWebView()

        webView.loadDataWithBaseURL(
            "https://app.ai2orbit.com",
            DASHBOARD_HTML,
            "text/html",
            "UTF-8",
            null
        )

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_NO_CACHE
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true
            allowContentAccess = false
            allowFileAccess = false
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.setBackgroundColor(Color.parseColor("#0a0e17"))
            }
        }

        webView.webChromeClient = WebChromeClient()
    }

    override fun onResume() {
        super.onResume()
        webView.evaluateJavascript("if(typeof resumeUpdates==='function')resumeUpdates();", null)
    }

    override fun onPause() {
        webView.evaluateJavascript("if(typeof pauseUpdates==='function')pauseUpdates();", null)
        super.onPause()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta name="color-scheme" content="dark">
<title>IDAB Ratings Fintech</title>
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
:root{
  --bg:#0a0e17;--bg2:#0f1420;--card:#1a1f2e;--card-hover:#232940;
  --accent:#00d4aa;--accent-dim:#00a88a;--cyan:#00bcd4;--blue:#448aff;
  --text:#ffffff;--text2:#b0bec5;--text3:#78909c;
  --green:#00e676;--green-bg:rgba(0,230,118,0.08);
  --red:#ff5252;--red-bg:rgba(255,82,82,0.08);
  --border:#1e2538;--orange:#ff9800
}
html,body{background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  overflow-x:hidden;-webkit-font-smoothing:antialiased;min-height:100vh}
body{padding:0 0 24px 0}

.header{
  background:linear-gradient(135deg,#0f1420 0%,#141a2a 100%);
  border-bottom:1px solid var(--border);
  padding:20px 16px 16px;position:sticky;top:0;z-index:100;
  backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px)
}
.header-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.logo{display:flex;align-items:center;gap:10px}
.logo-icon{
  width:36px;height:36px;border-radius:10px;
  background:linear-gradient(135deg,var(--accent),var(--cyan));
  display:flex;align-items:center;justify-content:center;
  font-weight:800;font-size:14px;color:var(--bg);letter-spacing:-0.5px
}
.logo-text{font-size:18px;font-weight:700;color:var(--text);letter-spacing:-0.3px}
.logo-sub{font-size:10px;color:var(--accent);font-weight:600;letter-spacing:1.5px;text-transform:uppercase;margin-top:1px}
.status-badge{
  display:flex;align-items:center;gap:6px;
  background:rgba(0,212,170,0.1);border:1px solid rgba(0,212,170,0.2);
  border-radius:20px;padding:5px 12px;font-size:11px;color:var(--accent);font-weight:600
}
.status-dot{width:6px;height:6px;border-radius:50%;background:var(--accent);
  animation:pulse 2s ease-in-out infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}

.market-bar{
  display:flex;gap:16px;overflow-x:auto;padding:2px 0;
  scrollbar-width:none;-ms-overflow-style:none
}
.market-bar::-webkit-scrollbar{display:none}
.market-bar-item{display:flex;align-items:center;gap:6px;white-space:nowrap;font-size:12px}
.market-bar-label{color:var(--text3);font-weight:500}
.market-bar-val{font-weight:700;font-variant-numeric:tabular-nums}
.market-bar-chg{font-size:11px;font-weight:600;padding:2px 6px;border-radius:4px}

.section{padding:16px}
.section-title{
  font-size:13px;font-weight:700;color:var(--text3);
  letter-spacing:1.2px;text-transform:uppercase;margin-bottom:14px;
  display:flex;align-items:center;gap:8px
}
.section-title::before{
  content:'';width:3px;height:14px;background:var(--accent);border-radius:2px
}

.charts-row{display:grid;grid-template-columns:1fr;gap:14px;margin-bottom:6px}
.chart-card{
  background:var(--card);border:1px solid var(--border);border-radius:16px;
  padding:16px;position:relative;overflow:hidden;
  transition:background 0.2s
}
.chart-card::before{
  content:'';position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,rgba(0,212,170,0.3),transparent)
}
.chart-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px}
.chart-title{font-size:13px;color:var(--text2);font-weight:600}
.chart-value{font-size:22px;font-weight:800;margin-top:2px;font-variant-numeric:tabular-nums;letter-spacing:-0.5px}
.chart-change{font-size:12px;font-weight:700;padding:3px 8px;border-radius:6px;display:inline-block;margin-top:4px}
.chart-change.up{color:var(--green);background:var(--green-bg)}
.chart-change.down{color:var(--red);background:var(--red-bg)}
canvas.chart-canvas{width:100%;height:80px;display:block;margin-top:4px}

.cards-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}
.market-card{
  background:var(--card);border:1px solid var(--border);border-radius:14px;
  padding:14px;position:relative;overflow:hidden;
  transition:transform 0.2s,background 0.2s
}
.market-card:active{transform:scale(0.98);background:var(--card-hover)}
.market-card .flag{font-size:18px;margin-bottom:6px;display:block}
.market-card .name{font-size:11px;color:var(--text3);font-weight:600;
  text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px}
.market-card .price{font-size:17px;font-weight:800;font-variant-numeric:tabular-nums;letter-spacing:-0.3px}
.market-card .change{font-size:11px;font-weight:700;margin-top:4px;
  display:inline-flex;align-items:center;gap:3px;padding:2px 7px;border-radius:5px}
.market-card .change.up{color:var(--green);background:var(--green-bg)}
.market-card .change.down{color:var(--red);background:var(--red-bg)}
.market-card .sparkline{position:absolute;bottom:0;right:0;width:60%;height:36px;opacity:0.3}

.market-card.full-width{grid-column:1/-1}

.footer{
  text-align:center;padding:24px 16px 8px;
  font-size:10px;color:var(--text3);letter-spacing:0.5px
}
.footer span{color:var(--accent);font-weight:600}

@media(min-width:480px){
  .charts-row{grid-template-columns:repeat(2,1fr)}
  .cards-grid{grid-template-columns:repeat(3,1fr)}
}
</style>
</head>
<body>

<div class="header">
  <div class="header-top">
    <div class="logo">
      <div class="logo-icon">IR</div>
      <div>
        <div class="logo-text">IDAB Ratings Fintech</div>
        <div class="logo-sub">AI2ORBIT Market Intelligence</div>
      </div>
    </div>
    <div class="status-badge">
      <div class="status-dot"></div>
      LIVE
    </div>
  </div>
  <div class="market-bar" id="marketBar"></div>
</div>

<div class="section">
  <div class="section-title">Index Performance</div>
  <div class="charts-row" id="chartsRow"></div>
</div>

<div class="section">
  <div class="section-title">Market Overview</div>
  <div class="cards-grid" id="cardsGrid"></div>
</div>

<div class="footer">
  Powered by <span>AI2ORBIT</span> &middot; Data simulated for demonstration<br>
  v7.0-api36-dark &middot; IDAB Ratings Engine
</div>

<script>
'use strict';

const INSTRUMENTS = [
  {id:'ftse',name:'FTSE 100',flag:'🇬🇧',base:8284.50,vol:0.12,dec:2,sym:'',chart:true,color:'#00d4aa'},
  {id:'sp500',name:'S&P 500',flag:'🇺🇸',base:5842.30,vol:0.10,dec:2,sym:'',chart:true,color:'#448aff'},
  {id:'nasdaq',name:'NASDAQ',flag:'🇺🇸',base:18432.75,vol:0.14,dec:2,sym:''},
  {id:'dax',name:'DAX',flag:'🇩🇪',base:18640.80,vol:0.11,dec:2,sym:'',chart:true,color:'#ff9800'},
  {id:'nikkei',name:'Nikkei 225',flag:'🇯🇵',base:38750.00,vol:0.13,dec:2,sym:''},
  {id:'eurgbp',name:'EUR/GBP',flag:'🇪🇺',base:0.8578,vol:0.03,dec:4,sym:''},
  {id:'usdgbp',name:'USD/GBP',flag:'🇺🇸',base:0.7912,vol:0.02,dec:4,sym:''},
  {id:'gold',name:'Gold',flag:'🥇',base:2385.60,vol:0.08,dec:2,sym:'$'},
  {id:'brent',name:'Brent Crude',flag:'🛢️',base:82.45,vol:0.15,dec:2,sym:'$'}
];

let prices={},histories={},sparklines={},updateTimer=null,running=true;

function init(){
  INSTRUMENTS.forEach(inst=>{
    prices[inst.id]={current:inst.base,prev:inst.base,change:0,changePct:0};
    histories[inst.id]=[];
    sparklines[inst.id]=[];
    for(let i=0;i<60;i++){
      const v=inst.base*(1+(Math.random()-0.5)*inst.vol*0.5);
      histories[inst.id].push(v);
      sparklines[inst.id].push(v);
    }
  });
  buildMarketBar();
  buildCharts();
  buildCards();
  tick();
  updateTimer=setInterval(tick,2000);
}

function tick(){
  if(!running)return;
  INSTRUMENTS.forEach(inst=>{
    const p=prices[inst.id];
    const drift=(Math.random()-0.495)*inst.vol*inst.base*0.002;
    const noise=(Math.random()-0.5)*inst.vol*inst.base*0.001;
    p.current=Math.max(p.current+drift+noise,inst.base*0.8);
    p.change=p.current-inst.base;
    p.changePct=(p.change/inst.base)*100;
    histories[inst.id].push(p.current);
    if(histories[inst.id].length>60)histories[inst.id].shift();
    sparklines[inst.id].push(p.current);
    if(sparklines[inst.id].length>20)sparklines[inst.id].shift();
  });
  updateMarketBar();
  updateCharts();
  updateCards();
}

function fmt(v,dec,sym){return (sym||'')+v.toFixed(dec).replace(/\B(?=(\d{3})+(?!\d))/g,',')}
function chgClass(v){return v>=0?'up':'down'}
function chgArrow(v){return v>=0?'▲':'▼'}

function buildMarketBar(){
  const bar=document.getElementById('marketBar');
  const quick=['ftse','sp500','dax','gold'];
  bar.innerHTML=quick.map(id=>{
    const inst=INSTRUMENTS.find(i=>i.id===id);
    return '<div class="market-bar-item">'+
      '<span class="market-bar-label">'+inst.name+'</span>'+
      '<span class="market-bar-val" id="bar-val-'+id+'"></span>'+
      '<span class="market-bar-chg" id="bar-chg-'+id+'"></span></div>';
  }).join('');
}

function updateMarketBar(){
  ['ftse','sp500','dax','gold'].forEach(id=>{
    const inst=INSTRUMENTS.find(i=>i.id===id);
    const p=prices[id];
    const valEl=document.getElementById('bar-val-'+id);
    const chgEl=document.getElementById('bar-chg-'+id);
    if(!valEl)return;
    valEl.textContent=fmt(p.current,inst.dec,inst.sym);
    valEl.style.color=p.changePct>=0?'var(--green)':'var(--red)';
    chgEl.textContent=chgArrow(p.changePct)+' '+Math.abs(p.changePct).toFixed(2)+'%';
    chgEl.style.color=p.changePct>=0?'var(--green)':'var(--red)';
    chgEl.style.background=p.changePct>=0?'var(--green-bg)':'var(--red-bg)';
  });
}

function buildCharts(){
  const row=document.getElementById('chartsRow');
  row.innerHTML=INSTRUMENTS.filter(i=>i.chart).map(inst=>{
    return '<div class="chart-card">'+
      '<div class="chart-header"><div>'+
        '<div class="chart-title">'+inst.flag+' '+inst.name+'</div>'+
        '<div class="chart-value" id="cv-'+inst.id+'"></div>'+
        '<div class="chart-change" id="cc-'+inst.id+'"></div>'+
      '</div></div>'+
      '<canvas class="chart-canvas" id="canvas-'+inst.id+'" height="80"></canvas></div>';
  }).join('');

  INSTRUMENTS.filter(i=>i.chart).forEach(inst=>{
    const c=document.getElementById('canvas-'+inst.id);
    c.width=c.offsetWidth*2;
    c.height=160;
  });
}

function updateCharts(){
  INSTRUMENTS.filter(i=>i.chart).forEach(inst=>{
    const p=prices[inst.id];
    const valEl=document.getElementById('cv-'+inst.id);
    const chgEl=document.getElementById('cc-'+inst.id);
    if(!valEl)return;
    valEl.textContent=fmt(p.current,inst.dec,inst.sym);
    chgEl.textContent=chgArrow(p.changePct)+' '+p.change.toFixed(inst.dec)+' ('+Math.abs(p.changePct).toFixed(2)+'%)';
    chgEl.className='chart-change '+chgClass(p.changePct);
    drawChart(inst);
  });
}

function drawChart(inst){
  const canvas=document.getElementById('canvas-'+inst.id);
  if(!canvas)return;
  const ctx=canvas.getContext('2d');
  const data=histories[inst.id];
  const w=canvas.width,h=canvas.height;
  ctx.clearRect(0,0,w,h);
  if(data.length<2)return;

  const min=Math.min(...data),max=Math.max(...data);
  const range=max-min||1;
  const pad=10;

  // Grid lines
  ctx.strokeStyle='rgba(30,37,56,0.6)';
  ctx.lineWidth=1;
  for(let i=0;i<4;i++){
    const y=pad+(h-pad*2)*(i/3);
    ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();
  }

  // Gradient fill
  const grad=ctx.createLinearGradient(0,0,0,h);
  const isUp=prices[inst.id].changePct>=0;
  const lineColor=inst.color;
  grad.addColorStop(0,lineColor+'40');
  grad.addColorStop(1,lineColor+'00');

  const pts=data.map((v,i)=>({
    x:(i/(data.length-1))*w,
    y:pad+(1-(v-min)/range)*(h-pad*2)
  }));

  // Fill area
  ctx.beginPath();
  ctx.moveTo(pts[0].x,h);
  pts.forEach(p=>ctx.lineTo(p.x,p.y));
  ctx.lineTo(pts[pts.length-1].x,h);
  ctx.closePath();
  ctx.fillStyle=grad;
  ctx.fill();

  // Line
  ctx.beginPath();
  ctx.moveTo(pts[0].x,pts[0].y);
  for(let i=1;i<pts.length;i++){
    const xc=(pts[i-1].x+pts[i].x)/2;
    const yc=(pts[i-1].y+pts[i].y)/2;
    ctx.quadraticCurveTo(pts[i-1].x,pts[i-1].y,xc,yc);
  }
  ctx.lineTo(pts[pts.length-1].x,pts[pts.length-1].y);
  ctx.strokeStyle=lineColor;
  ctx.lineWidth=2.5;
  ctx.stroke();

  // End dot
  const last=pts[pts.length-1];
  ctx.beginPath();
  ctx.arc(last.x,last.y,4,0,Math.PI*2);
  ctx.fillStyle=lineColor;
  ctx.fill();
  ctx.beginPath();
  ctx.arc(last.x,last.y,7,0,Math.PI*2);
  ctx.strokeStyle=lineColor+'60';
  ctx.lineWidth=2;
  ctx.stroke();
}

function buildCards(){
  const grid=document.getElementById('cardsGrid');
  grid.innerHTML=INSTRUMENTS.map(inst=>{
    return '<div class="market-card" id="mc-'+inst.id+'">'+
      '<span class="flag">'+inst.flag+'</span>'+
      '<div class="name">'+inst.name+'</div>'+
      '<div class="price" id="mp-'+inst.id+'"></div>'+
      '<div class="change" id="mch-'+inst.id+'"></div>'+
      '<canvas class="sparkline" id="spark-'+inst.id+'" width="120" height="36"></canvas></div>';
  }).join('');
}

function updateCards(){
  INSTRUMENTS.forEach(inst=>{
    const p=prices[inst.id];
    const priceEl=document.getElementById('mp-'+inst.id);
    const chgEl=document.getElementById('mch-'+inst.id);
    if(!priceEl)return;
    priceEl.textContent=fmt(p.current,inst.dec,inst.sym);
    chgEl.textContent=chgArrow(p.changePct)+' '+Math.abs(p.changePct).toFixed(2)+'%';
    chgEl.className='change '+chgClass(p.changePct);
    drawSparkline(inst);
  });
}

function drawSparkline(inst){
  const canvas=document.getElementById('spark-'+inst.id);
  if(!canvas)return;
  const ctx=canvas.getContext('2d');
  const data=sparklines[inst.id];
  const w=canvas.width,h=canvas.height;
  ctx.clearRect(0,0,w,h);
  if(data.length<2)return;
  const min=Math.min(...data),max=Math.max(...data);
  const range=max-min||1;
  const isUp=prices[inst.id].changePct>=0;
  const color=isUp?'#00e676':'#ff5252';

  const grad=ctx.createLinearGradient(0,0,0,h);
  grad.addColorStop(0,color+'30');
  grad.addColorStop(1,color+'00');

  const pts=data.map((v,i)=>({
    x:(i/(data.length-1))*w,
    y:2+(1-(v-min)/range)*(h-4)
  }));

  ctx.beginPath();
  ctx.moveTo(pts[0].x,h);
  pts.forEach(p=>ctx.lineTo(p.x,p.y));
  ctx.lineTo(pts[pts.length-1].x,h);
  ctx.closePath();
  ctx.fillStyle=grad;
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(pts[0].x,pts[0].y);
  pts.forEach(p=>ctx.lineTo(p.x,p.y));
  ctx.strokeStyle=color;
  ctx.lineWidth=1.5;
  ctx.stroke();
}

function pauseUpdates(){running=false}
function resumeUpdates(){running=true}

window.addEventListener('resize',()=>{
  INSTRUMENTS.filter(i=>i.chart).forEach(inst=>{
    const c=document.getElementById('canvas-'+inst.id);
    if(c){c.width=c.offsetWidth*2;c.height=160;drawChart(inst)}
  });
});

init();
</script>
</body>
</html>
"""
    }
}
